module.exports = {
    reactNative: {
        bridgeless: false, // Désactive le mode Bridgeless
    },
};
