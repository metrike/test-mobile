const { getDefaultConfig } = require('@expo/metro-config');

/**
 * Metro configuration
 * https://docs.expo.dev/guides/customizing-metro/
 *
 * @type {import('metro-config').MetroConfig}
 */
const defaultConfig = getDefaultConfig(__dirname);

const customConfig = {
    // Ajoutez ici des options supplémentaires si nécessaire
};

module.exports = {
    ...defaultConfig,
    ...customConfig,
};
